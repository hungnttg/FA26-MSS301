package com.example.demo.bai01.controller;

import com.example.demo.common.*;
import com.example.demo.bai01.model.Product;
import com.example.demo.bai01.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")
public class ProductController {

    @Autowired
    private ProductRepository repository;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Product>>> getAll() {
        List<Product> list = repository.findAll();
        return ResponseEntity.ok(ApiResponse.success(list, "Fetch all products successfully"));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Product>> getById(@PathVariable Long id) {
        Product item = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
        return ResponseEntity.ok(ApiResponse.success(item, "Found Product with id: " + id));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Product>> create(@RequestBody Product item) {
        Product saved = repository.save(item);
        return ResponseEntity.ok(ApiResponse.success(saved, "Created Product successfully"));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Product>> update(@PathVariable Long id, @RequestBody Product updateData) {
        Product existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
        
        existing.setName(updateData.getName());
        existing.setPrice(updateData.getPrice());
        existing.setDescription(updateData.getDescription());
        
        Product saved = repository.save(existing);
        return ResponseEntity.ok(ApiResponse.success(saved, "Updated Product successfully"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Product not found with id: " + id);
        }
        repository.deleteById(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Deleted Product with id: " + id + " successfully"));
    }
}
