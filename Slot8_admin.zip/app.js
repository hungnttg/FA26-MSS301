//npm i body-parser
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const productRoutes = require('./routes/products');
const app = express();
//cau hinh view engine la ejs
app.set('view engine','ejs');
//middleware
app.use(bodyParser.urlencoded({extended: true}));
//ket noi mongodb
mongoose.connect('mongodb://localhost:27017/a1',{

}).then(()=>{
    console.log('ket noi mongodb thanh cong');
}).catch(err=>{
    console.log('Ket noi mongodb that bai: ',err.message);
});
//su dung route quan tri san pham
app.use('/',productRoutes);
//lang nghe
app.listen(3012,()=>{
    console.log('server dang chay o cong 3012');
});