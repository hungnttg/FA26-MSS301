package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.example.demo", nameGenerator = org.springframework.context.annotation.FullyQualifiedAnnotationBeanNameGenerator.class)
@EnableJpaRepositories(basePackages = "com.example.demo")
@EntityScan(basePackages = "com.example.demo")
@EnableFeignClients(basePackages = "com.example.demo")
@EnableEurekaServer
//khi chay Demo2Application (main app) => quet va kich hoat giao tiep http
//inter-service trong cum microservice
public class Demo2Application {

    public static void main(String[] args) {
        SpringApplication.run(Demo2Application.class, args);
        System.out.println("==================================================");
        System.out.println("MSS301 Demo2 Application Started Successfully!");
        System.out.println("Swagger UI: http://localhost:8080/swagger-ui/index.html");
        System.out.println("Slot 9 Dynamic Message:  http://localhost:8080/api/config_items/message");
        System.out.println("Slot 9 Config Items:     http://localhost:8080/api/config_items");
        System.out.println("Slot 10 Circuit Breaker: http://localhost:8080/api/circuit_breakers/test");
        System.out.println("Slot 10 Resilience Logs: http://localhost:8080/api/resilience_logs");
        System.out.println("Slot 11 Docker Info:     http://localhost:8080/api/docker_items/info");
        System.out.println("Slot 11 Docker Items:    http://localhost:8080/api/docker_items");
        System.out.println("==================================================");
    }
}
