package com.example.demo.bai06.client;

import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/feign_client")
@CrossOrigin(origins = "*")
public class FeignCLientController {
    @Autowired
    private FeignClientInterface feignCLientInterface;
    @GetMapping("/fetch/{id}")
    public ResponseEntity<ApiResponse<Object>> fetchOrderViaFeign(@PathVariable Long id){
        Object orderData = feignCLientInterface.getOrderById(id);
        return ResponseEntity.ok(ApiResponse.success(orderData,"Fetch data qua openFeign thanh cong"));
    }
}
/*
Feign là thư viện giúp các MS giao tiếp với nhau qua http một ách đơn giản
-----
Khi chưa có Feign:
Cách gọi phức tạp hơn như sau:
RestTemplate  res = new RestTemplate();
String url = “http://localhost:8081/api/products”+id;
Product p = res.getForObject(url,Product.class)
----
Khi có Feign
chỉ cần
@FeignClient
----
Ý nghĩa: Dùng feign để che dấu sự phác tạp khi sử dụng API http
* */