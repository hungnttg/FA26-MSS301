package com.example.demo.slot8.repository;

import com.example.demo.slot8.model.ApiDesign;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApiDesignRepository extends JpaRepository<ApiDesign, Long> {
}
