package com.example.demo.bai06.repository;

import com.example.demo.bai06.model.OrderFeign;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderFeignRepository extends JpaRepository<OrderFeign,Long> {
}
