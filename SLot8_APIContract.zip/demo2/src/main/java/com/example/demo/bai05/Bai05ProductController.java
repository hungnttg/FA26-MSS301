package com.example.demo.bai05;

import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot5/api/products")
@CrossOrigin(origins = "*")
public class Bai05ProductController {

    @Autowired
    private Bai05ProductRepository repository;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Bai05Product>>> getAll() {
        List<Bai05Product> list = repository.findAll();
        return ResponseEntity.ok(ApiResponse.success(list, "Fetch all bai05 products successfully"));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Bai05Product>> getById(@PathVariable Long id) {
        Bai05Product item = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bai05Product not found with id: " + id));
        return ResponseEntity.ok(ApiResponse.success(item, "Found Bai05Product with id: " + id));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Bai05Product>> create(@RequestBody Bai05Product item) {
        Bai05Product saved = repository.save(item);
        return ResponseEntity.ok(ApiResponse.success(saved, "Created Bai05Product successfully"));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Bai05Product>> update(@PathVariable Long id, @RequestBody Bai05Product updateData) {
        Bai05Product existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bai05Product not found with id: " + id));

        existing.setName(updateData.getName());
        existing.setPrice(updateData.getPrice());
        existing.setDescription(updateData.getDescription());

        Bai05Product saved = repository.save(existing);
        return ResponseEntity.ok(ApiResponse.success(saved, "Updated Bai05Product successfully"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Bai05Product not found with id: " + id);
        }
        repository.deleteById(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Deleted Bai05Product with id: " + id + " successfully"));
    }
}
