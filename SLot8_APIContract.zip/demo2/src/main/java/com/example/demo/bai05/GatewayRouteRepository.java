package com.example.demo.bai05;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GatewayRouteRepository extends JpaRepository<GatewayRoute,Long> {
}
