package com.example.demo.bai05;

import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping({"/api/gateway_routes", "/api/routes", "/slot5/api/routes"})
@CrossOrigin(origins = "*")
public class GatewayRouteController {
    @Autowired
    private GatewayRouteRepository repo;
    @GetMapping
    public ResponseEntity<ApiResponse<List<GatewayRoute>>> getAll(){
        List<GatewayRoute> list = repo.findAll();
        return ResponseEntity.ok(ApiResponse.success(list,"Fetch all gateway routes successfully"));
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<GatewayRoute>> getById(@PathVariable Long id){
        GatewayRoute item = repo.findById(id)
                .orElseThrow(()->new RuntimeException("Gateway route not found with id: "+id));
        return ResponseEntity.ok(ApiResponse.success(item,"Found GatewayRoute successfully"));
    }
    @PostMapping
    public ResponseEntity<ApiResponse<GatewayRoute>> create(@RequestBody GatewayRoute route){
        GatewayRoute saved  = repo.save(route);
        return ResponseEntity.ok(ApiResponse.success(saved,"Created GatewayRoute successfully"));
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<GatewayRoute>> update(@PathVariable Long id, @RequestBody GatewayRoute updateData){
        GatewayRoute existing = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Gateway route not found with id: " + id));
        existing.setName(updateData.getName());
        existing.setPrice(updateData.getPrice());
        existing.setDescription(updateData.getDescription());
        GatewayRoute saved = repo.save(existing);
        return ResponseEntity.ok(ApiResponse.success(saved, "Updated GatewayRoute successfully"));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id){
        if (!repo.existsById(id)) {
            throw new RuntimeException("Gateway route not found with id: " + id);
        }
        repo.deleteById(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Deleted GatewayRoute with id: " + id + " successfully"));
    }
}
