package com.example.demo.bai05;

import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot5/api/orders")
@CrossOrigin(origins = "*")
public class Bai05OrderController {
    @Autowired
    private Bai05OrderRepository repo;
    @GetMapping
    public ResponseEntity<ApiResponse<List<Bai05Order>>> getAll(){
        List<Bai05Order> list = repo.findAll();
        return ResponseEntity.ok(ApiResponse.success(list,"Fetch all bai05 orders successfully"));
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Bai05Order>> getById(@PathVariable Long id){
        Bai05Order item = repo.findById(id)
                .orElseThrow(()->new RuntimeException("Bai05Order not found with id: "+id));
        return ResponseEntity.ok(ApiResponse.success(item,"Found Bai05Order with id: "+id));
    }
    @PostMapping
    public ResponseEntity<ApiResponse<Bai05Order>> create(@RequestBody Bai05Order item){
        Bai05Order saved = repo.save(item);
        return ResponseEntity.ok(ApiResponse.success(saved,"Created Bai05Order successfully"));
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Bai05Order>> update(@PathVariable Long id,@RequestBody Bai05Order updateData){
        Bai05Order existing = repo.findById(id).orElseThrow(()->new RuntimeException("Bai05Order not found with id: "+id));
        existing.setName(updateData.getName());
        existing.setPrice(updateData.getPrice());
        existing.setDescription(updateData.getDescription());
        Bai05Order saved = repo.save(existing);
        return ResponseEntity.ok(ApiResponse.success(saved,"Updated Bai05Order successfully"));
    }
}
