package com.example.demo.bai05;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Bai05ProductRepository extends JpaRepository<Bai05Product, Long> {
}
