package com.example.demo.slot8.controller;

import com.example.demo.slot8.model.ApiDesign;
import com.example.demo.slot8.repository.ApiDesignRepository;
import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/api_designs")
@CrossOrigin(origins = "*")
public class ApiDesignController {

    @Autowired
    private ApiDesignRepository repository;

    @GetMapping
    public ResponseEntity<ApiResponse<List<ApiDesign>>> getAll() {
        List<ApiDesign> list = repository.findAll();
        return ResponseEntity.ok(ApiResponse.success(list, "Fetch all api_designs successfully"));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ApiDesign>> getById(@PathVariable Long id) {
        ApiDesign item = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("ApiDesign not found with id: " + id));
        return ResponseEntity.ok(ApiResponse.success(item, "Found ApiDesign with id: " + id));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<ApiDesign>> create(@RequestBody ApiDesign item) {
        ApiDesign saved = repository.save(item);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(saved, "Created ApiDesign successfully"));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ApiDesign>> update(@PathVariable Long id, @RequestBody ApiDesign updateData) {
        ApiDesign existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("ApiDesign not found with id: " + id));

        existing.setName(updateData.getName());
        existing.setPrice(updateData.getPrice());
        existing.setDescription(updateData.getDescription());

        ApiDesign saved = repository.save(existing);
        return ResponseEntity.ok(ApiResponse.success(saved, "Updated ApiDesign successfully"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<String>> delete(@PathVariable Long id) {
        ApiDesign existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("ApiDesign not found with id: " + id));
        repository.delete(existing);
        return ResponseEntity.ok(ApiResponse.success("Deleted ApiDesign with id: " + id, "Delete successful"));
    }
}
