package com.example.demo.bai06.controller;

import com.example.demo.bai02.model.Order;
import com.example.demo.bai06.model.OrderFeign;
import com.example.demo.bai06.repository.OrderFeignRepository;
import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/feign_orders")
@CrossOrigin(origins = "*")
public class OrderFeignController {
    @Autowired
    private OrderFeignRepository repo;
    @GetMapping
    public ResponseEntity<ApiResponse<List<OrderFeign>>> getAll(){
        List<OrderFeign> list = repo.findAll();
        return ResponseEntity.ok(ApiResponse.success(list,"Fetch Thanh cong"));
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<OrderFeign>> getById(@PathVariable Long id){
        OrderFeign item = repo.findById(id).orElseThrow(()->new RuntimeException("Khong tim thay id"));
        return ResponseEntity.ok(ApiResponse.success(item,"Tim thay Id"));

    }
    @PostMapping
    public ResponseEntity<ApiResponse<OrderFeign>> create(@RequestBody OrderFeign item){
        OrderFeign saved = repo.save(item);
        return ResponseEntity.ok(ApiResponse.success(saved,"Them thanh cong"));
    }
}
