package com.example.demo.bai06.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "demo2",url = "http://localhost:8080")
public interface FeignClientInterface {
    @GetMapping("/api/feign_orders/{id}")
    Object getOrderById(@PathVariable("id") Long id);
}
