package com.example.demo.bai06.model;

import jakarta.persistence.*;

@Entity
@Table(name = "feign_orders")
public class OrderFeign {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    public OrderFeign(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public OrderFeign() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
