package com.example.demo.slot12.repository;

import com.example.demo.slot12.model.DockerBoot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DockerBootRepository extends JpaRepository<DockerBoot,Long> {
}
