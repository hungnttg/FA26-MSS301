package com.example.demo.slot11.repository;

import com.example.demo.slot11.model.DockerItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DockerItemRepository extends JpaRepository<DockerItem,Long> {
}
