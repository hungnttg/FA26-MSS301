package com.example.demo.slot11.controller;

import com.example.demo.common.ApiResponse;
import com.example.demo.slot11.model.DockerItem;
import com.example.demo.slot11.repository.DockerItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.net.InetAddress;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/docker_items")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class DockerItemController {
    private final DockerItemRepository repo;
//    1.TRa cau thong tin runtime container /node (chung minh ung dung dang chay trong Docker COntainer
    @GetMapping("/info")
    public ApiResponse<Map<String,Object>> getDockerInfo(){
        Map<String,Object> info = new LinkedHashMap<>();
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            //trong docker, HostNam chinh la Container ID
            info.put("containerHost",localhost.getHostName());
            info.put("containerIp",localhost.getHostAddress());
        } catch (Exception e){
            info.put("containerHost","unknown");
        }
        info.put("os",System.getProperty("os.name"));
        info.put("javaVersion",System.getProperty("java.version"));
        info.put("status","Running in Docker Container");
        return ApiResponse.success(info,"Container runtime details fetched successfully");
    }
//    CRUD API cho DockerItem
    @GetMapping
    public ApiResponse<List<DockerItem>> getAll(){
        return ApiResponse.success(repo.findAll(),"Fetch all docker_items successfully");
    }
    @GetMapping("/{id}")
    public ApiResponse<DockerItem> getById(@PathVariable Long id){
        return ApiResponse.success(repo.findById(id).orElseThrow(),"Found DockerItem whith id: "+id);
    }
    @PostMapping
    public ApiResponse<DockerItem> create(@RequestBody DockerItem item){
        return ApiResponse.success(repo.save(item),"Created DockerItem successfully");
    }
    @PutMapping("/{id}")
    public ApiResponse<DockerItem> update(@PathVariable Long id,@RequestBody DockerItem item){
        item.setId(id);
        return ApiResponse.success(repo.save(item),"Updated DockerItem successfully");
    }
    @DeleteMapping("/{id}")
    public ApiResponse<String> delete(@PathVariable Long id){
        repo.deleteById(id);
        return ApiResponse.success("Deleted ID: "+id,"Deleted DockerItem successfully");
    }
    /*
    * Chay truc tiep tren local (khong qua docker)
    * mvn spring-boot:run
    * ---- Trien khai tu dong voi docker compose
    * 1.dong goi thanh file jar
    * mvn clean package -DskipTests
    * 2.chay
    * docker-compose up -d --build
    * chu y: neu muon dung, dung lenh: docker-compose down
    * -----Cach 3: Build va chay thu cong bang Docker CLI
    * mvn clean pakage -DskipTests
    * docker build -t demo2:latest
    * docker run -p 8080:8080 demo2:latest
    * */
}
