package com.example.demo.slot12.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "docker_boots")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DockerBoot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private Double price;
    private String description;
    public DockerBoot(String name,Double price,String description){
        this.name=name;
        this.price=price;
        this.description=description;
    }
}
