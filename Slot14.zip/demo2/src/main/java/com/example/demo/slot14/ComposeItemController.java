package com.example.demo.slot14;

import jakarta.persistence.*;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/compose_items")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ComposeItemController {

    private final ComposeItemRepo repo;

    // 1. Kiểm tra kết nối đa container qua Docker Compose (App <-> MySQL qua backend-net)
    @GetMapping("/status")
    public Map<String, Object> status() {
        return Map.of(
                "service", "demo2-app",
                "orchestration", "Docker Compose",
                "database_connected", repo.count() >= 0
        );
    }

    // 2. Lấy danh sách item
    @GetMapping
    public List<ComposeItem> getAll() {
        return repo.findAll();
    }

    // 3. Thêm item mới
    @PostMapping
    public ComposeItem create(@RequestBody ComposeItem item) {
        return repo.save(item);
    }
}

@Entity
@Table(name = "compose_items")
@Data
class ComposeItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Double price;
    private String description;
}

interface ComposeItemRepo extends JpaRepository<ComposeItem, Long> {}
