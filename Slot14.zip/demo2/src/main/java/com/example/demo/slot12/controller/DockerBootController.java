package com.example.demo.slot12.controller;

import com.example.demo.common.ApiResponse;
import com.example.demo.slot11.model.DockerItem;
import com.example.demo.slot12.model.DockerBoot;
import com.example.demo.slot12.repository.DockerBootRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.print.Doc;
import java.util.List;

@RestController
@RequestMapping("/api/docker_boots")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class DockerBootController {
    private final DockerBootRepository repository;
    //1.lay toan bo danh sach dockerBoot
    @GetMapping
    public ResponseEntity<ApiResponse<List<DockerBoot>>> getAll(){
        return ResponseEntity.ok(ApiResponse.success(repository.findAll(),"Fetch all docker_boots successfuly"));
    }
    //2. lay thong tin theo id
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<DockerBoot>> getById(@PathVariable Long id){
        DockerBoot item = repository.findById(id).orElseThrow(()-> new RuntimeException("Docker not found with id: "+id));
        return ResponseEntity.ok(ApiResponse.success(item,"Found DockerBoot Wiith id: "+id));
    }
    //3. them moi
    @PostMapping
    public ResponseEntity<ApiResponse<DockerBoot>> create(@RequestBody DockerBoot item){
        return ResponseEntity.ok(ApiResponse.success(repository.save(item),"Created DOckerBoot Successfully"));
    }
    //4.cap nhat
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<DockerBoot>> update(@PathVariable Long id, @RequestBody DockerBoot item){
        if(!repository.existsById(id)){
            throw  new RuntimeException("DockerBoor not found with id: "+id);
        }
        item.setId(id);
        return ResponseEntity.ok(ApiResponse.success(repository.save(item),"Updated DockerBoot successfully"));
    }
    //5. xoa
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id){
        if(!repository.existsById(id)){
            throw  new RuntimeException("DockerBoor not found with id: "+id);
        }
        return ResponseEntity.ok(ApiResponse.success(null,"Deleted DockerBoot with id: "+id+ " successfully"));
    }
}
/*
* Run:
* C1: mvn spring-boot:run => xu ly voi csdl tren may tinh
* C2: Chay bang Docker Compose
* mvn clean package -DskipTests (dong goi jar)
* khoi dong ca Container MySQL va COntainer Spring Boot
* docker-compose up -d --build
* //chú ý:
* Khi chạy docker-compose up -d --build vẫn chuayj bình thường vì
* docker-compose.yml đã có sẵn khối SPRING_DATASOURCE_URL đè lên localhost
* */
