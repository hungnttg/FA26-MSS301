-- =====================================================
-- DATABASE SCRIPT FOR LESSON 11 / SLOT 12:
-- ĐÓNG GÓI SPRING BOOT VỚI DOCKER & TIÊM BIẾN MÔI TRƯỜNG CSDL ĐỘNG
-- DATABASE NAME: a12
-- =====================================================

CREATE DATABASE IF NOT EXISTS `a12`
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `a12`;

-- Drop table if exists to ensure clean state
DROP TABLE IF EXISTS `docker_boots`;

-- Create table `docker_boots`
CREATE TABLE `docker_boots` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `price` DOUBLE DEFAULT 0.0,
  `description` VARCHAR(500)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data
INSERT INTO `docker_boots` (`name`, `price`, `description`) VALUES
('Docker Boot Item 01', 199.0, 'Initial sample data for Lesson 11 / Slot 12 Spring Boot Docker'),
('Docker Boot Item 02', 349.99, 'Second sample entry for testing Environment Variable Injection');

-- Verification query
SELECT * FROM `docker_boots`;
