-- =====================================================
-- DATABASE SCRIPT FOR LESSON 10 / SLOT 11:
-- DOCKER CĂN BẢN CHO VI DỊCH VỤ (CONTAINERIZATION)
-- DATABASE NAME: a12
-- =====================================================

CREATE DATABASE IF NOT EXISTS `a12`
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `a12`;

-- Drop table if exists to ensure clean state
DROP TABLE IF EXISTS `docker_items`;

-- Create table `docker_items`
CREATE TABLE `docker_items` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `price` DOUBLE DEFAULT 0.0,
  `description` VARCHAR(500)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data
INSERT INTO `docker_items` (`name`, `price`, `description`) VALUES
('Docker Item 01', 150.0, 'Initial sample data for Lesson 10 / Slot 11 Docker Container'),
('Docker Item 02', 299.99, 'Second sample entry for testing Dockerized Spring Boot App');

-- Verification query
SELECT * FROM `docker_items`;
