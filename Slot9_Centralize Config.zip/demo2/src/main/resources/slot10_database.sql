-- =====================================================
-- DATABASE SCRIPT FOR LESSON 09 / SLOT 10:
-- XỬ LÝ LỖI & RESILIENCE VỚI RESILIENCE4J (CIRCUIT BREAKER)
-- DATABASE NAME: a12
-- =====================================================

CREATE DATABASE IF NOT EXISTS `a12`
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `a12`;

-- Drop table if exists to ensure clean state
DROP TABLE IF EXISTS `resilience_logs`;

-- Create table `resilience_logs`
CREATE TABLE `resilience_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `price` DOUBLE DEFAULT 0.0,
  `description` VARCHAR(500),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data
INSERT INTO `resilience_logs` (`name`, `price`, `description`) VALUES
('Circuit Breaker Log 01', 99.0, 'Initial sample data for Lesson 9 / Slot 10'),
('Circuit Breaker Log 02', 150.0, 'Second sample entry for testing MySQL a12');

-- Verification query
SELECT * FROM `resilience_logs`;
