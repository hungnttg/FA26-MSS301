-- =====================================================
-- DATABASE SCRIPT FOR LESSON 08 / SLOT 9:
-- QUẢN LÝ CẤU HÌNH TẬP TRUNG VỚI SPRING CLOUD CONFIG
-- DATABASE NAME: a12
-- =====================================================

CREATE DATABASE IF NOT EXISTS `a12`
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `a12`;

-- Drop table if exists to ensure clean state
DROP TABLE IF EXISTS `configs`;

-- Create table `configs`
CREATE TABLE `configs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `price` DOUBLE DEFAULT 0.0,
  `description` VARCHAR(500),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data for `configs`
INSERT INTO `configs` (`name`, `price`, `description`) VALUES
('Sample Config 01', 150.0, 'Initial sample data for Lesson 8 / Slot 9'),
('Sample Config 02', 299.99, 'Second sample entry for testing MySQL a12');

-- Verification query
SELECT * FROM `configs`;
