package com.example.demo.slot9.repository;

import com.example.demo.slot9.model.ConfigItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConfigItemRepository extends JpaRepository<ConfigItem,Long> {
}
