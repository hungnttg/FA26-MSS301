package com.example.demo.slot8.controller;

import com.example.demo.common.ApiResponse;
import com.example.demo.slot8.model.Customer;
import com.example.demo.slot8.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ExpressionException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
@CrossOrigin(origins = "*")
public class CustomerController {
    @Autowired
    private CustomerRepository repository;
    @GetMapping
    public ResponseEntity<ApiResponse<List<Customer>>> getAll(){
        List<Customer> list = repository.findAll();
        return ResponseEntity.ok(ApiResponse.success(list,"Fetch all api_designs successfully"));
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Customer>> getById(@PathVariable Long id){
        Customer item = repository.findById(id)
                .orElseThrow(()->new RuntimeException("Customer not found with id: "+id));
        return ResponseEntity.ok(ApiResponse.success(item,"Found Customer with ud: "+id));
    }
    @PostMapping
    public ResponseEntity<ApiResponse<Customer>> create(@RequestBody Customer item){
        Customer saved = repository.save(item);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(saved,"Created Customer successfully"));
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Customer>> update(@PathVariable Long id, @RequestBody Customer updateData){
        Customer existing = repository.findById(id).orElseThrow(()->new ExpressionException("Customer not found with id: "+id));
        existing.setName(updateData.getName());
        existing.setPrice(updateData.getPrice());
        existing.setDescription(updateData.getDescription());
        Customer saved = repository.save(existing);
        return ResponseEntity.ok(ApiResponse.success(saved,"Updated Customer successfully"));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<String>> delete(@PathVariable Long id){
        Customer existing =repository.findById(id).orElseThrow(()->new RuntimeException("Customer not found with id: "+id));
        repository.delete(existing);
        return ResponseEntity.ok(ApiResponse.success("Deleted Customer with id: "+id,"Delete successful"));
    }
}

