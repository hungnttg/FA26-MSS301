package com.example.demo.slot9.controller;

import com.example.demo.common.ApiResponse;
import com.example.demo.slot9.model.ConfigItem;
import com.example.demo.slot9.repository.ConfigItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/config_items")
@RefreshScope
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ConfigItemController {
    private final ConfigItemRepository repo;
    @Value("${app.message:Hello Slot 9 - Centralized Config Management!}")
    private String message;
    @GetMapping("/message")
    public ApiResponse<String> getMessage(){
        return ApiResponse.success(message,"Fetched dynamic config via @RefreshScope");
    }
    @GetMapping
    public ApiResponse<List<ConfigItem>> getAll(){
        return ApiResponse.success(repo.findAll(),"Sucess");
    }
    @GetMapping("/{id}")
    public ApiResponse<ConfigItem> getById(@PathVariable Long id){
        return ApiResponse.success(repo.findById(id).orElseThrow(),"Found");
    }
    @PostMapping
    public ApiResponse<ConfigItem> create(@RequestBody ConfigItem item){
        return ApiResponse.success(repo.save(item),"Created");
    }
    @PutMapping("/{id}")
    public ApiResponse<ConfigItem> update(@PathVariable Long id,@RequestBody ConfigItem item){
        item.setId(id);
        return ApiResponse.success(repo.save(item),"Updated");
    }
    @DeleteMapping("/{id}")
    public ApiResponse<String> delete(@PathVariable Long id){
        repo.deleteById(id);
        return ApiResponse.success("Deleted: "+id,"Delete successful");
    }
}
