package com.example.demo.slot9.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "configs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConfigItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private Double price = 0.0;
    private String description;
    private LocalDateTime createdAt = LocalDateTime.now();
}
