package com.example.demo.slot10.controller;

import com.example.demo.common.ApiResponse;
import com.example.demo.slot10.model.ResilenceLog;
import com.example.demo.slot10.repository.ResilenceLogRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping({"/api/circuit_breakers","/api/resilence","/api/resilience_logs"})
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class CircuitBreakerController {
    private final ResilenceLogRepository logRepo;
    private final RestTemplate restTemplate=createRestTemplate();
    private static RestTemplate createRestTemplate(){
        SimpleClientHttpRequestFactory factor=new SimpleClientHttpRequestFactory();
        factor.setConnectTimeout(2000);
        factor.setReadTimeout(2000);
        return new RestTemplate(factor);
    }
    //1. thu nghiam ngat mach & fallback khi cong 999 bij sap
    @GetMapping("/test")
    @CircuitBreaker(name = "default",fallbackMethod = "fallbackResponse")
    public ApiResponse<String> testCircuitBreaker(){
        //goi toi 1 service khong ton tai tai cong 9999 de mo phong loi sap dich vu
        String res=restTemplate.getForObject("http://localhost:9999/api/unstable",String.class);
        return ApiResponse.success(res,"Service responded norrmally");
    }
    //ham du phong Fallback duoc kich hoat tuc thi khi dich vu dich gap su co sap/timeout
    public ApiResponse<String> fallbackResponse(Throwable t){
        logRepo.save(new ResilenceLog(null,"Circuit Breaker Fallback Activated",99.0,"Service is down (port 9999): "+t.getMessage(), LocalDateTime.now()));
        return ApiResponse.success("Fallback Response Active: Service is down or timing out. Error: "+t.getMessage(),"Circuit Breaker Fallback Activated");
    }
    //CRUD quan ly Resilience logs
    @GetMapping
    public ApiResponse<List<ResilenceLog>> getAll(){
        return ApiResponse.success(logRepo.findAll(),"Fetch all resilience_logs successfully");
    }

}
