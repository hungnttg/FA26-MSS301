package com.example.demo.slot10.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "resilience_logs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResilenceLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private Double price;
    private String description;
    private LocalDateTime created = LocalDateTime.now();
}
