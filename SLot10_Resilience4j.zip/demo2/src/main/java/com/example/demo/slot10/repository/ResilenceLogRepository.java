package com.example.demo.slot10.repository;

import com.example.demo.slot10.model.ResilenceLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ResilenceLogRepository extends JpaRepository<ResilenceLog,Long> {
}
