package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.example.demo")
@EnableJpaRepositories(basePackages = "com.example.demo")
@EntityScan(basePackages = "com.example.demo")
@EnableFeignClients(basePackages = "com.example.demo")
//khi chay Demo2Application (main app) => quet va kich hoat giao tiep http
//inter-service trong cum microservice
public class Demo2Application {

    public static void main(String[] args) {
        SpringApplication.run(Demo2Application.class, args);
        System.out.println("==================================================");
        System.out.println("MSS301 Demo2 Application Started Successfully!");
        System.out.println("Swagger UI: http://localhost:8080/swagger-ui/index.html");
        System.out.println("Order Service (Bai 02): http://localhost:8080/api/orders");
        System.out.println("==================================================");
    }
}
