package com.example.demo.bai03;

import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cloud_infos")
@CrossOrigin(origins = "*")
public class CloudInfoController {
    @Autowired
    private CloudInfoRepository repo;
    @GetMapping
    public ResponseEntity<ApiResponse<List<CloudInfo>>> getAll(){
        List<CloudInfo> list = repo.findAll();
        return ResponseEntity.ok(ApiResponse.success(list,"Fetch all cloud_infos successfully"));
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<CloudInfo>> getById(@PathVariable Long id){
        CloudInfo item = repo.findById(id).orElseThrow(()-> new RuntimeException("CloudInfo not fount with id: "+id));
        return ResponseEntity.ok(ApiResponse.success(item,"Found CloudInfo with id: "+id));
    }
    @PostMapping
    public ResponseEntity<ApiResponse<CloudInfo>> create(@RequestBody CloudInfo item){
        CloudInfo saved = repo.save(item);
        return ResponseEntity.ok(ApiResponse.success(saved,"Created CloudInfo successfully"));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id){
        if(!repo.existsById(id)){
            throw new RuntimeException("Could not found with id: "+id);
        }
        repo.deleteById(id);
        return ResponseEntity.ok(ApiResponse.success(null,"Deleted CloudInfo with id: "+id));
    }
// những cái áp dụng:
//    1, tích hợp BOM quản lý phiên bản Spring Cloud trong pom.xml dependencyManagement
//    2. tich hop openFeign
//    3. cau hinh kha nanhg chiu loi bang resilence4j
//    4. su dung cloud-native trong application.properties
}
